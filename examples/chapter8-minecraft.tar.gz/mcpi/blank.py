import minecraft

mc = minecraft.Minecraft.create()

mc.setBlocks(-100,0,-100,100,1,100,41)
mc.setBlocks(-100,1,-100,100,100,100,0)

mc.player.setPos(0,0,2)
